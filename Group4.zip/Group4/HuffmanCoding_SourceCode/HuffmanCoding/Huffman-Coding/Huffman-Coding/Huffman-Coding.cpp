#include <iostream>
#include <queue>
#include <unordered_map>
#include <string>
#include <sstream>
#include <fstream>
using namespace std;

struct Node {
    int data;
    char character;
    Node* left;
    Node* right;

    Node(int data, char character = 0, Node* left = nullptr, Node* right = nullptr)
        : data(data), character(character), left(left), right(right) {}

    bool isLeaf() { return left == nullptr && right == nullptr; }
};

class HuffmanCoding {
private:

    unordered_map<char, int> freqMap;
    unordered_map<char, string> codeMap;
    string str;

    struct NodeComparator {
        bool operator()(Node* left, Node* right) {
            if (left->data == right->data) {
                bool leftIsInternal = left->left != nullptr || left->right != nullptr;
                bool rightIsInternal = right->left != nullptr || right->right != nullptr;
                if (leftIsInternal != rightIsInternal) {
                    return rightIsInternal;
                }
            }
            return left->data > right->data;
        }
    };

    Node* buildTree(unordered_map<char, int>& freqMap) {
        priority_queue<Node*, vector<Node*>, NodeComparator> q;
        for (auto& entry : freqMap) {
            q.push(new Node(entry.second, entry.first));
        }

        if (q.empty()) {
            return nullptr;
        }

        while (q.size() > 1) {
            Node* x = q.top(); q.pop();
            Node* y = q.top(); q.pop();
            Node* newNode = new Node(x->data + y->data, 0, x, y);
            q.push(newNode);
        }
        return q.top();
    }

    void buildCode(Node* node, string code) {
        if (!node) return;
        if (node->isLeaf()) {
            codeMap[node->character] = code;
            return;
        }
        buildCode(node->left, code + "0");
        buildCode(node->right, code + "1");
    }

    void countFreq(const string& str) {
        freqMap.clear();
        for (char c : str) {
            freqMap[c]++;
        }
    }

    void freeTree(Node* node) {
        if (!node) return;
        freeTree(node->left);
        freeTree(node->right);
        delete node;
    }

public:
    Node* root;
    HuffmanCoding() : root(nullptr) {}

    //The destructor ~HuffmanCoding() will be executed 
    //when an object of the HuffmanCoding class goes out of scope
    // or is explicitly deleted. 
    ~HuffmanCoding() {
        freeTree(root);
    }

    HuffmanCoding& process(const string& str) {
        this->str = str;
        countFreq(str);
        root = buildTree(freqMap);
        codeMap.clear();
        buildCode(root, "");
        return *this;
    }

    string encode() {
        if (codeMap.empty()) {
            return "";
        }
        stringstream ss;
        for (char c : str) {
            ss << codeMap[c];
        }
        return ss.str();
    }

    string decode(const string& encoded) {
        if (!root) {
            return "";
        }
        Node* node = root;
        string decodedString;
        for (char c : encoded) {
            if (c == '0') {
                if (node->left) node = node->left;
                //else return decodedString;
            }
            else if (c == '1') {
               if (node->right) node = node->right;
				//else return decodedString;
            }
            else {
                return "Invalid encoded string";
            }
            if (node->isLeaf()) {
                decodedString += node->character;
                node = root;
            }
        }
        if (node != root) {
            return "Invalid encoded string";
        }
        return decodedString;
    }
    void countLeaf(Node* root, int& sum, int depth)
    {
        if (!root) return;
        if (root->isLeaf())
        {
            sum = sum + 8 + depth;
        }
        countLeaf(root->left, sum, depth + 1);
        countLeaf(root->right, sum, depth + 1);
    }
    void helperSaveHuffmanTreeToFile(Node* root, ofstream& fout)
    {
        if (!root) return;
        short int numberOfBranches = 0;
        if (root->left && root->right) numberOfBranches = 2;
        else if (!root->left && !root->right) numberOfBranches = 0;
        else numberOfBranches = 1;
        fout.write((char*)&numberOfBranches, sizeof(short int));
        if (root->isLeaf())
        {
            fout << root->character;
            return;
        }
        char branchToTake = '0';
        if (root->left)
        {
            branchToTake = '0';
            fout.write((char*)&branchToTake, sizeof(char));
            helperSaveHuffmanTreeToFile(root->left, fout);
        }
        if (root->right)
        {
            branchToTake = '1';
            fout.write((char*)&branchToTake, sizeof(char));
            helperSaveHuffmanTreeToFile(root->right, fout);
        }
    }
    void saveHuffmanTreeToFile(const string& fileName)
    {
        ofstream fout;
        fout.open(fileName, ios::binary);
        if (!fout.is_open()) return;
        helperSaveHuffmanTreeToFile(this->root, fout);
    }
   
    void helperLoadHuffmanTreeFromFile(Node*& root, ifstream& fin) 
    {
        short int numberOfBranches;
        fin.read((char*)&numberOfBranches, sizeof(short int));
        if (numberOfBranches == 0) 
        {
            char encodedCharacter;
            fin.read((char*)&encodedCharacter, sizeof(char));
            root = new Node(0, encodedCharacter); 
            return;
        }
        root = new Node(0); 
        for (int i = 0; i < numberOfBranches; ++i) 
        {
            char branchToTake;
            fin.read((char*)&branchToTake, sizeof(char));
            if (branchToTake == '0') 
            {
                helperLoadHuffmanTreeFromFile(root->left, fin);
            }
            else if (branchToTake == '1') 
            {
                helperLoadHuffmanTreeFromFile(root->right, fin);
            }
        }
    }
    void loadHuffmanTreeFromFile(const string& fileName)
    {
        ifstream fin;
        fin.open(fileName, ios::binary);
        if (!fin.is_open()) return;
        helperLoadHuffmanTreeFromFile(this->root, fin);
    }


};

// function to read a file and return the string by using input string stream
string readFileIntoString(const string& path)
{
    ifstream file;
    file.open(path);
    if (!file) {
        cerr << "Unable to open file " << path;
        exit(1);   // call system to stop
    }
    stringstream strStream;
    strStream << file.rdbuf(); //read the file
    return strStream.str(); //str holds the content of the file
}

// function to write a string of encoded text bit by bit into a binary file
void writeBitsToFile(const string& bitString, const string& outputFileName) 
{
    std::ofstream outFile(outputFileName, std::ios::binary);
    if (!outFile) 
    {
        std::cerr << "Error opening file for writing." << std::endl;
        return;
    }

    int bitStringLength = bitString.length();
    outFile.write(reinterpret_cast<const char*>(&bitStringLength), sizeof(int));
    int numBytes = (bitStringLength + 7) / 8; // Calculate the number of bytes needed
    std::vector<unsigned char> byteArray(numBytes, 0);

     //Pack bits into bytes
    for (int i = 0; i < bitStringLength; ++i) 
    {
        if (bitString[i] == '1') 
        {
            byteArray[i / 8] |= (1 << (7 - (i % 8)));
        }
    }

     //Write bytes to file
    outFile.write(reinterpret_cast<const char*>(byteArray.data()), byteArray.size());
    outFile.close();
}


// read bits of encoded string from file
string readBitsFromFile(const std::string& fileName) 
{
    std::ifstream inFile(fileName, std::ios::binary);
    if (!inFile) {
        std::cerr << "Error opening file for reading." << std::endl;
        return "";
    }
    int bitStringLength = 0;
    inFile.read(reinterpret_cast<char*>(&bitStringLength), sizeof(int));
    int numBytes = (bitStringLength + 7) / 8;
    std::vector<unsigned char> byteArray(numBytes, 0);

    // Read bytes from file
    inFile.read(reinterpret_cast<char*>(byteArray.data()), byteArray.size());
    inFile.close();

    // Unpack bits from bytes
    string bitString;
    for (int i = 0; i < bitStringLength; ++i) {
        bitString += (byteArray[i / 8] & (1 << (7 - (i % 8)))) ? '1' : '0';
    }

    return bitString;
}



bool checkEncodedCharacter(const string& encodedCharacter)
{
    int i = 0;
	for (char c : encodedCharacter)
	{
        if (c != '0' && c != '1')
        {
            cout << i << endl;
            cout << c << endl;
            return false;
        }
        ++i;
	}
	return true;
}
void compressFile(const string& inputFile, const string & outputHuffmanTree, const string& encodedFile)
{
    HuffmanCoding hc;
    string inputString = readFileIntoString(inputFile);
    hc.process(inputString);
    string encoded = hc.encode();
    writeBitsToFile(encoded, encodedFile);
    hc.saveHuffmanTreeToFile(outputHuffmanTree);
}
void readCompressedFile(const string& outputHuffmanTree, const string& encodedFile)
{
	HuffmanCoding hc;
	string res;
	string encodedString = readBitsFromFile(encodedFile);
    hc.root = new Node(0);
	hc.loadHuffmanTreeFromFile(outputHuffmanTree);
	if (checkEncodedCharacter(encodedString) == false)
	{
		cout << "Invalid encoded string" << endl;
		return;
	}
	res = hc.decode(encodedString);
	cout << res << endl;
}

int main()
{
   
      const string encodedHuffmanTree = "huffmanTree.bin";
      const string encodedText = "encoded.bin";
      // put the directory to the file you want to compress here (in the string inputFile)
      const string inputFile = "input.txt";
	  compressFile(inputFile, encodedHuffmanTree, encodedText);
      readCompressedFile(encodedHuffmanTree, encodedText);
      return 0;
}